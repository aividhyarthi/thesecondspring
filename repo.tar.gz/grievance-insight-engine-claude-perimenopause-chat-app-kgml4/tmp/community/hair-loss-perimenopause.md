---
question: "I'm losing so much hair in the shower. My ponytail is half what it used to be. What can I do?"
askerName: Deepa
askerAge: 46
askerCity: Kolkata
category: Hair & Skin
answeredBy: The Second Spring Team
replies:
  - name: Kavitha M.
    text: "Getting my ferritin checked was the turning point for me. My haemoglobin was normal so my previous doctor hadn't flagged anything, but my ferritin was 14 — very depleted. My new doctor put me on iron supplements and by month four the shedding had noticeably reduced. Hair grows slowly so you need patience, but it did change."
  - name: Priya R.
    text: "My dermatologist added zinc to the panel and it came back very low. Between correcting my ferritin AND my zinc, plus a topical treatment, the shedding reduced noticeably within four months. Hair responds slowly but it does respond. Get the full panel — not just haemoglobin."
relatedJournals:
  - title: "Hair and Skin Guide"
    href: /guide/hair-skin
  - title: "Skin and Hair Symptoms"
    href: /guide/symptoms/skin-hair
  - title: "How to Test for Perimenopause"
    href: /blog/how-to-test-for-perimenopause
tags: ["hair loss", "hair thinning", "perimenopause", "oestrogen", "ferritin"]
date: 2026-05-01
---

Hair thinning during perimenopause is driven by two overlapping processes, and understanding both helps explain why treatment needs to address more than one thing.

The first factor is falling oestrogen. Oestrogen normally prolongs the anagen (growth) phase of the hair cycle. As oestrogen declines, more hairs shift into the shedding phase — you'll notice more in the shower drain, on your pillow, in your brush.

The second factor is relative androgen dominance. As oestrogen falls, androgens (which are always present in small amounts in women) become relatively stronger in proportion. Androgens act on genetically sensitive hair follicles to miniaturise them — producing progressively thinner, shorter hairs, particularly at the crown and temples. This is the same mechanism as male pattern hair loss.

Before starting any hair treatment, please get bloodwork done. Ferritin (stored iron) is crucial — hair loss occurs when ferritin drops below 50 ng/mL even when haemoglobin is still normal. Many doctors only check haemoglobin; you need to specifically ask for ferritin. Also check: thyroid (TSH + fT4), vitamin D, and zinc. These are common deficiencies in this age group and all cause hair shedding that is often more straightforward to reverse than hormonally-driven loss.

For hormonally-driven thinning, a topical hair treatment (available at pharmacies — ask your dermatologist which is right for you) has the strongest evidence for hormonally-driven thinning. It takes 4–6 months to see visible results and must be used continuously. HRT can also help by restoring oestrogen's protective effect on follicles.

While hair is fragile: avoid tight hairstyles, heat styling, and chemical treatments. Eat adequate protein. The hair will respond to a combination of correct nutritional support and targeted treatment.
